package com.cjava.anotacion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(AppConfig.class)
public class GlobalConfig {
	
	@Bean(name = "holaMundo")
	public HolaMundo holaMundo(){
		return new HolaMundo();
	}

}
