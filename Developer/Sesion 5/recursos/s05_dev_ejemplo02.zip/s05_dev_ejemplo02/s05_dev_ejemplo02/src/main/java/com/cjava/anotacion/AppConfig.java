package com.cjava.anotacion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean(name = "objHolaMundo")
	public HolaMundo holaMundo(){
		return new HolaMundo();
	}

}
