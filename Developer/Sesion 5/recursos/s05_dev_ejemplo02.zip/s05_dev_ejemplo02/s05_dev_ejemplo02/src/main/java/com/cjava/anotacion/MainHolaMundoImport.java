package com.cjava.anotacion;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainHolaMundoImport {

public static void main(String[] args) {

    ApplicationContext applicationContext = new AnnotationConfigApplicationContext(GlobalConfig.class);
    HolaMundo holaMundo = (HolaMundo) applicationContext.getBean("objHolaMundo");
    holaMundo.setMensaje("Mensaje");
    holaMundo.mostrar();

}

}
