package com.cjava.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainSimple {

public static void main(String[] args) {

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("basicBeans.xml");
        HolaMundo holaMundo = (HolaMundo) applicationContext.getBean("holaMundo");
        holaMundo.setMensaje("Hola Mundo");
        holaMundo.mostrar();

}

}
