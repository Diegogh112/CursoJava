package com.cjava.anotacion;


public class HolaMundo {
	
	private String mensaje;
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public void mostrar(){
		System.out.println(mensaje);
	}

}
