package com.cjava.anotacion;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainHolaMundo {

public static void main(String[] args) {

    ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
    HolaMundo holaMundo = (HolaMundo) applicationContext.getBean("objHolaMundo");
    holaMundo.setMensaje("Mensaje");
    holaMundo.mostrar();

}

}
