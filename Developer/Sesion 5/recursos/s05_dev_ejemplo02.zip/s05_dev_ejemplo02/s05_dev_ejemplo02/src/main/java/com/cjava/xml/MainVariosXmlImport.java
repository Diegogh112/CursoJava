package com.cjava.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainVariosXmlImport {

public static void main(String[] args) {

    ApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[]{"basicImport.xml"});
    HolaMundo holaMundo = applicationContext.getBean("holaMundo", HolaMundo.class);
    holaMundo.setMensaje("Hola Mundo");
    holaMundo.mostrar();

    Mensaje mensaje = applicationContext.getBean("mensaje", Mensaje.class);
    mensaje.setMensaje("Hola Mundo desde Mensaje");
    mensaje.mostrar();

}

}
