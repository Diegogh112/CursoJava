package com.cjava.demo.anotacion;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Mensaje {
	
	private String mensaje;
	
	public Mensaje() {
		System.out.println("Constructor " + this.getClass().getName());
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public void mostrar(){
		System.out.println(mensaje);
	}

}
