package com.cjava.demo.anotacion;

import org.springframework.stereotype.Component;

@Component
public class HolaMundo {
	
	private String mensaje;
	
	public HolaMundo() {
		System.out.println("Constructor " + this.getClass().getName());
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public void mostrar(){
		System.out.println(mensaje);
	}

}
