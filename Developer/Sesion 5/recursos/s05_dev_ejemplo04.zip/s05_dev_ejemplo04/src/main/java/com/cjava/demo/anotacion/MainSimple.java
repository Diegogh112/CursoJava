package com.cjava.demo.anotacion;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainSimple {

	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("ambitoAnotacion.xml");
		
		HolaMundo holaMundo1 = (HolaMundo) applicationContext.getBean("holaMundo");
		HolaMundo holaMundo2 = (HolaMundo) applicationContext.getBean("holaMundo");
		HolaMundo holaMundo3 = (HolaMundo) applicationContext.getBean("holaMundo");
		
		
		Mensaje mensaje1 = (Mensaje) applicationContext.getBean("mensaje");
		Mensaje mensaje2 = (Mensaje) applicationContext.getBean("mensaje");
		Mensaje mensaje3 = (Mensaje) applicationContext.getBean("mensaje");

	}

}
