package com.cjava.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainSimple {

	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("diConfigSimple.xml");
		Impresion impresion = (Impresion) applicationContext.getBean("impresion");
		impresion.getMensaje().mostrar();
		
		Impresion impresion2 = (Impresion) applicationContext.getBean("impresion2");
		impresion2.getMensaje().mostrar();

	}

}
