package com.cjava.demo;

public class Impresion {
	
	private Mensaje mensaje;
	
	public Impresion() {
	}

	public Impresion(Mensaje mensaje) {
		super();
		System.out.println("usando constructor");
		this.mensaje = mensaje;
	}

	public void setMensaje(Mensaje mensaje) {
		System.out.println("usando metodo set");
		this.mensaje = mensaje;
	}
	
	public Mensaje getMensaje() {
		return mensaje;
	}

}
