package com.cjava.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05DevEjemplo01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
