package com.cjava.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication

public class S05DevEjemplo01Application {

    public static void main(String[] args) {
        SpringApplication.run(S05DevEjemplo01Application.class, args);
    }

}
