package com.cjava.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CursoRestController {

    @GetMapping("/saludo")
    public String hello(@RequestParam(value = "name", defaultValue = "cjava") String name) {
        return String.format("Hola %s!", name);
    }

}
