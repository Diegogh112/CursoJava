package com.cjava.demo.model.daos.impl;

import com.cjava.demo.model.daos.CursoDao;
import com.cjava.demo.model.entities.Curso;
import com.cjava.demo.util.AbstractEntity;

public class CursoDaoImpl extends AbstractEntity<Curso,String> implements CursoDao {

    public CursoDaoImpl(Class<Curso> objeto) {
        super(objeto);
    }
}
