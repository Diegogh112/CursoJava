package com.cjava.demo.model.daos;

import com.cjava.demo.model.entities.Curso;

import java.util.List;

public interface CursoDao {
    public void create(Curso curso);
    public List<Curso> findAll();
    public void update(Curso curso);
    public void delete(String id);
    public Curso find(String id);
}
