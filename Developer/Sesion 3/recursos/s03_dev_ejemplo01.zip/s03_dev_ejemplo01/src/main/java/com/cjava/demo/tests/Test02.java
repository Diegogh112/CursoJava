package com.cjava.demo.tests;

import com.cjava.demo.model.daos.CursoDao;
import com.cjava.demo.model.daos.impl.CursoDaoImpl;
import com.cjava.demo.model.entities.Curso;

public class Test02 {
    public static void main(String[] args) {
        Curso curso = new Curso();
        curso.setId("C04");
        curso.setNombre("Architec");
        curso.setCreditos(5);

        CursoDao dao = new CursoDaoImpl(Curso.class);
        dao.create(curso);

        dao.findAll().forEach(System.out::println);
    }
}
