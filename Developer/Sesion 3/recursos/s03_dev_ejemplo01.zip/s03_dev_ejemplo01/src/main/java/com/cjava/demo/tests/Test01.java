package com.cjava.demo.tests;

import com.cjava.demo.model.entities.Curso;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import java.util.List;
import java.util.Map;

import static jakarta.persistence.Persistence.createEntityManagerFactory;
import static org.hibernate.cfg.SchemaToolingSettings.JAKARTA_HBM2DDL_DATABASE_ACTION;
import static org.hibernate.tool.schema.Action.CREATE;

public class Test01 {
    public static void main(String[] args) {
        var fabrica = createEntityManagerFactory("escuelaPU",
                Map.of(JAKARTA_HBM2DDL_DATABASE_ACTION, CREATE));

        EntityManager em = fabrica.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Curso c");

        List<Curso> lista = (List<Curso>)query.getResultList();

        lista.forEach(System.out::println);
    }
}
