package com.cjava.demo.tests;

public class Test03 {
    public static void main(String[] args) {
        //TODO: implementar el codigo necesario para crear un alumno y
        // mostrar la lista de alumnos en la base de datos


    }
}
