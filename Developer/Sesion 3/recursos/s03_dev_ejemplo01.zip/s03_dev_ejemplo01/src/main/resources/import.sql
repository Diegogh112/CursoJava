insert into curso (chrCurCodigo,vchCurNombre,intCurCreditos) values ('c01','Programmer',5);
insert into curso (chrCurCodigo,vchCurNombre,intCurCreditos) values ('c02','Developer',5);
insert into curso (chrCurCodigo,vchCurNombre,intCurCreditos) values ('c03','Expert',5);
