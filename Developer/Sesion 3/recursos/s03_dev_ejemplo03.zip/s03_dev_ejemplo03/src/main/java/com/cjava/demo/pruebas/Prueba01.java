/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cjava.demo.pruebas;

import com.cjava.demo.daos.CategoriaDao;
import com.cjava.demo.daos.ProductoDao;
import com.cjava.demo.entidades.Categoria;
import com.cjava.demo.entidades.Producto;
import com.cjava.demo.entidades.ProductoPK;

/**
 *
 * @author emaravi
 */
public class Prueba01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CategoriaDao cdao = new CategoriaDao(Categoria.class);
        ProductoDao pdao = new ProductoDao(Producto.class);
        
        Categoria ca = cdao.find("L");
        ProductoPK ppk = new ProductoPK(6,ca.getTipo().charAt(0));
                
        Producto p = new Producto();
        p.setProductoPK(ppk);
        p.setDescripcion("zzzzzz");
        p.setPrecio(Float.valueOf(11));
        p.setStatus('A');
        p.setStock(120);
        
        pdao.create(p);
        for(Producto producto : pdao.findAll()){
            System.out.println("descripcion"+producto.getDescripcion());
            System.out.println("Precio"+producto.getPrecio());
            System.out.println("Stock"+producto.getStock());
            System.out.println("---------------------------");
        }
        
        
        
    }
    
}
