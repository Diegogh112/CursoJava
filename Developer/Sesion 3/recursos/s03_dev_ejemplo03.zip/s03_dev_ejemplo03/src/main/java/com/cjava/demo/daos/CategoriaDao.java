package com.cjava.demo.daos;

import com.cjava.demo.entidades.Categoria;
import com.cjava.demo.util.AbstractEntity;

/**
 *
 * @author emaravi
 */
public class CategoriaDao extends AbstractEntity<Categoria,String>{

    public CategoriaDao(Class<Categoria> objeto) {
        super(objeto);
    }
    
}
