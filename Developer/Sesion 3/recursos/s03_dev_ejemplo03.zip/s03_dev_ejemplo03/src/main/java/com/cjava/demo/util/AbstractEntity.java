package com.cjava.demo.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.List;
import java.util.Map;

import static jakarta.persistence.Persistence.createEntityManagerFactory;
import static org.hibernate.cfg.SchemaToolingSettings.JAKARTA_HBM2DDL_DATABASE_ACTION;
import static org.hibernate.tool.schema.Action.CREATE;

public abstract class AbstractEntity<T,V> {
    EntityManagerFactory emf;
    EntityManager em;
    Class<T> objeto;

    public AbstractEntity(Class<T> objeto){
        emf = createEntityManagerFactory("demoPU",
                // export the inferred database schema
                Map.of(JAKARTA_HBM2DDL_DATABASE_ACTION, CREATE));
        em = emf.createEntityManager();
        this.objeto = objeto;
    }

    public void create(T t) {
        em.getTransaction().begin();
        em.persist(t);
        em.getTransaction().commit();
    }

    public List<T> findAll() {
        List<T> lista;
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<T> cq = cb.createQuery(objeto);
        Root<T> s = cq.from(objeto);
        cq.select(s);
        TypedQuery<T> q = em.createQuery(cq);
        lista = q.getResultList();
        return lista;
    }

    public void update(T t) {
        em.getTransaction().begin();
        em.merge(t);
        em.getTransaction().commit();
    }

    public void delete(V id) {

        T c = find(id);
        em.getTransaction().begin();
        if(c!=null){
            em.remove(c);
        }
        em.getTransaction().commit();

    }

    public T find(V id) {
        em.getTransaction().begin();
        T t=em.find(objeto, id);
        em.getTransaction().commit();
        return t;
    }
    public List<T> findRange(int[] range) {
        CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
        cq.select(cq.from(objeto));
        Query q = em.createQuery(cq);
        q.setMaxResults(range[1] - range[0] + 1);
        q.setFirstResult(range[0]);
        return q.getResultList();
    }

    public int count() {
        CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
        Root<T> rt = cq.from(objeto);
        cq.select(em.getCriteriaBuilder().count(rt));
        Query q = em.createQuery(cq);
        return ((Long) q.getSingleResult()).intValue();
    }



}
