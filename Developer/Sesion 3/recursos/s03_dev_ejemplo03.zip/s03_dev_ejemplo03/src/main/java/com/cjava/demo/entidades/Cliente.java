/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cjava.demo.entidades;

import jakarta.persistence.*;
import java.io.Serializable;

/**
 *
 * @author emaravi
 */
@Entity
@Table(name = "clientes")
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c"),
    @NamedQuery(name = "Cliente.findByCodigoCli", query = "SELECT c FROM Cliente c WHERE c.codigoCli = :codigoCli"),
    @NamedQuery(name = "Cliente.findByLogin", query = "SELECT c FROM Cliente c WHERE c.login = :login"),
    @NamedQuery(name = "Cliente.findByPassword", query = "SELECT c FROM Cliente c WHERE c.password = :password"),
    @NamedQuery(name = "Cliente.findByNombre", query = "SELECT c FROM Cliente c WHERE c.nombre = :nombre"),
    @NamedQuery(name = "Cliente.findByDireccion", query = "SELECT c FROM Cliente c WHERE c.direccion = :direccion"),
    @NamedQuery(name = "Cliente.findByFonoCasa", query = "SELECT c FROM Cliente c WHERE c.fonoCasa = :fonoCasa"),
    @NamedQuery(name = "Cliente.findByFonoMovil", query = "SELECT c FROM Cliente c WHERE c.fonoMovil = :fonoMovil"),
    @NamedQuery(name = "Cliente.findByTsexo", query = "SELECT c FROM Cliente c WHERE c.tsexo = :tsexo"),
    @NamedQuery(name = "Cliente.findByEmail", query = "SELECT c FROM Cliente c WHERE c.email = :email"),
    @NamedQuery(name = "Cliente.findByCiudad", query = "SELECT c FROM Cliente c WHERE c.ciudad = :ciudad"),
    @NamedQuery(name = "Cliente.findBySaldo", query = "SELECT c FROM Cliente c WHERE c.saldo = :saldo")})
public class Cliente implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigoCli")
    private Integer codigoCli;


    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    @Column(name = "password")
    private String password;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "direccion")
    private String direccion;
    @Column(name = "fono_casa")
    private String fonoCasa;
    @Column(name = "fono_movil")
    private String fonoMovil;
    @Column(name = "tsexo")
    private Character tsexo;
    @Column(name = "email")
    private String email;
    @Column(name = "ciudad")
    private String ciudad;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "saldo")
    private Float saldo;

    public Cliente() {
    }

    public Cliente(Integer codigoCli) {
        this.codigoCli = codigoCli;
    }

    public Cliente(Integer codigoCli, String login) {
        this.codigoCli = codigoCli;
        this.login = login;
    }

    public Integer getCodigoCli() {
        return codigoCli;
    }

    public void setCodigoCli(Integer codigoCli) {
        this.codigoCli = codigoCli;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFonoCasa() {
        return fonoCasa;
    }

    public void setFonoCasa(String fonoCasa) {
        this.fonoCasa = fonoCasa;
    }

    public String getFonoMovil() {
        return fonoMovil;
    }

    public void setFonoMovil(String fonoMovil) {
        this.fonoMovil = fonoMovil;
    }

    public Character getTsexo() {
        return tsexo;
    }

    public void setTsexo(Character tsexo) {
        this.tsexo = tsexo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Float getSaldo() {
        return saldo;
    }

    public void setSaldo(Float saldo) {
        this.saldo = saldo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoCli != null ? codigoCli.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.codigoCli == null && other.codigoCli != null) || (this.codigoCli != null && !this.codigoCli.equals(other.codigoCli))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cjava.entidades.Cliente[ codigoCli=" + codigoCli + " ]";
    }
    
}
