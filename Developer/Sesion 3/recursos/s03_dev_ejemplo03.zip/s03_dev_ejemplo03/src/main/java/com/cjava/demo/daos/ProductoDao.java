/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cjava.demo.daos;

import com.cjava.demo.entidades.Producto;
import com.cjava.demo.util.AbstractEntity;

/**
 *
 * @author emaravi
 */
public class ProductoDao extends AbstractEntity<Producto,String>{

    public ProductoDao(Class<Producto> objeto) {
        super(objeto);
    }
    
}
