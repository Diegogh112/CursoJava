insert into Categoria(tipo, descripcion) values('L', 'Lacteos');
insert into Categoria(tipo, descripcion) values('B', 'Bebidas');
insert into Categoria(tipo, descripcion) values('C', 'Artefactos');

insert into productos(tipo, descripcion, precio, stock, status) values
    ('L', 'Yogurt 1Litro', 2.30, 100,'A');
insert into productos(tipo, descripcion, precio, stock, status) values
    ('L', 'Queso fresco', 1.5, 49,'A');
insert into productos(tipo, descripcion, precio, stock, status) values
    ('B', 'Agua Mineral 1 litro', 1.5, 20,'A');
insert into productos(tipo, descripcion, precio, stock, status) values
    ('C', 'Lavadora LG 10 pies3',230, 15,'A');
insert into productos(tipo, descripcion, precio, stock, status) values
    ('C', 'Cocina Red Star LX32', 450, 20,'A');


insert into clientes
(login,password,nombre,direccion, fono_casa, fono_movil, tsexo,email,ciudad) values('cjava','cjava','Maria Gracia', 'Lima','3454556','p7451212','M','alumno01@cjavaperu.com.com','LI');

insert into clientes
(login,password,nombre,direccion, fono_casa, fono_movil, tsexo,email,ciudad) values('wbe','wbe','Fabiola Garcia', 'Piura','1221222','999888999','M','alumno02@cjavaperu.com.com','PI');

