insert into cliente (idcli,nombre) values (100, 'juan')
insert into factura (nro,importe,idcli) values (10, 120, 100)
insert into factura (nro,importe,idcli) values (20, 150, 100)
insert into factura (nro,importe,idcli) values (30, 180, 100)