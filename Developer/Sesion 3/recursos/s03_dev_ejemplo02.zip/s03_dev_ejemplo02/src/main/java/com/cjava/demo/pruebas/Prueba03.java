package com.cjava.demo.pruebas;

import com.cjava.demo.domain.daos.impl.ClienteDaoImpl;
import com.cjava.demo.domain.entities.Cliente;
import com.cjava.demo.domain.entities.Factura;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Prueba03 {
    public static void main(String[] args) {
        Cliente cliente = new Cliente(200, "Edwin Maravi");
        List<Factura> lista = new ArrayList<Factura>();
        lista.add(new Factura(57, new BigDecimal(2400) , cliente));
        lista.add(new Factura(58, new BigDecimal(2500) , cliente));

        ClienteDaoImpl dao = new ClienteDaoImpl();
        dao.create(cliente);
        //TDOD: Implementar el metodo update de FacturaDaoImpl

        //TDOD: Implementar el metodo delete de FacturaDaoImpl

        //TDOD: Implementar el metodo find de FacturaDaoImpl

        dao.findAll().forEach(System.out::println);

    }
}
