package com.cjava.demo.domain.daos.impl;

import com.cjava.demo.domain.daos.ClienteDao;
import com.cjava.demo.domain.entities.Cliente;
import com.cjava.demo.util.AbstractEntity;

public class ClienteDaoImpl2 extends AbstractEntity<Cliente,Integer> implements ClienteDao{

	public ClienteDaoImpl2(Class<Cliente> objeto) {
		super(objeto);
	}
	

}
