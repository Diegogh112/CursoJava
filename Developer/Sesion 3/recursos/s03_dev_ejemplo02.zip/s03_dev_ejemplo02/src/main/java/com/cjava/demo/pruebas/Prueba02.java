package com.cjava.demo.pruebas;

import com.cjava.demo.domain.entities.Cliente;
import com.cjava.demo.domain.entities.Factura;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import static jakarta.persistence.Persistence.createEntityManagerFactory;
import static org.hibernate.cfg.SchemaToolingSettings.JAKARTA_HBM2DDL_DATABASE_ACTION;
import static org.hibernate.tool.schema.Action.CREATE;

public class Prueba02 {
    public static void main(String[] args) {
        var fabrica = createEntityManagerFactory("escuelaPU",
                // export the inferred database schema
                Map.of(JAKARTA_HBM2DDL_DATABASE_ACTION, CREATE));

        Cliente cliente = new Cliente(199, "Angelica Mora");
        List<Factura> lista = new ArrayList<Factura>();
        lista.add(new Factura(51, new BigDecimal(2400) , cliente));
        lista.add(new Factura(52, new BigDecimal(2500) , cliente));
        lista.add(new Factura(53, new BigDecimal(2600) , cliente));
        cliente.setFacturaList(lista);

        // persist an entity
        inSession(fabrica, entityManager -> {
            entityManager.persist(cliente);
        });

        EntityManager em = fabrica.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Cliente c");

        @SuppressWarnings("unchecked")
        List<Cliente> listaCli = (List<Cliente>)query.getResultList();
        for(Cliente c: listaCli) {
            System.out.println(c);
            for(Factura f: c.getFacturaList()) {
                System.out.println(f);
            }
        }

    }
    static void inSession(EntityManagerFactory factory, Consumer<EntityManager> work) {
        var entityManager = factory.createEntityManager();
        var transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            work.accept(entityManager);
            transaction.commit();
        }
        catch (Exception e) {
            if (transaction.isActive()) transaction.rollback();
            throw e;
        }
        finally {
            entityManager.close();
        }
    }
}
