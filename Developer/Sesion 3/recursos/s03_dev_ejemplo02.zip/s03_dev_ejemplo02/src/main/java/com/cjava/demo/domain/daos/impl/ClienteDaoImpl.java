package com.cjava.demo.domain.daos.impl;

import com.cjava.demo.domain.daos.ClienteDao;
import com.cjava.demo.domain.entities.Cliente;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;

import java.util.List;
import java.util.Map;

import static jakarta.persistence.Persistence.createEntityManagerFactory;
import static org.hibernate.cfg.SchemaToolingSettings.JAKARTA_HBM2DDL_DATABASE_ACTION;
import static org.hibernate.tool.schema.Action.CREATE;

public class ClienteDaoImpl implements ClienteDao{

	EntityManagerFactory fabrica;
	EntityManager em;

	public ClienteDaoImpl() {
		super();
		fabrica = createEntityManagerFactory("escuelaPU",
				// export the inferred database schema
				Map.of(JAKARTA_HBM2DDL_DATABASE_ACTION, CREATE));
		em = fabrica.createEntityManager();
	}

	public void create(Cliente cliente) {
		try{
			em.getTransaction().begin();
			em.persist(cliente);
			em.getTransaction().commit();
		}catch (NullPointerException ex){
			em.getTransaction().rollback();
		}
	}

	public void update(Cliente cliente) {
		em.getTransaction().begin();
		em.merge(cliente);
		em.getTransaction().commit();
		
	}

	public void delete(Integer id) {
		em.getTransaction().begin();
		em.remove(id);
		em.getTransaction().commit();
		
	}

	public Cliente find(Integer id) {
		return em.find(Cliente.class, id);
	}

	public List<Cliente> findAll() {
		//Query query = em.createQuery("SELECT c FROM Cliente c");
		//Query query = em.createNamedQuery("Cliente.findAll");
		CriteriaQuery cq = em.getCriteriaBuilder().createQuery(Cliente.class);
		List<Cliente> lista;
		try{
			//lista =query.getResultList();

			cq.select(cq.from(Cliente.class));
			lista = cq.getOrderList();
		}catch (NoResultException ex){
			lista = null;
		}
		return lista;
	}

}
