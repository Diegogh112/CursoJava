package com.cjava.demo.domain.entities;


import jakarta.persistence.*;
import org.hibernate.validator.constraints.Length;

import java.io.Serializable;
import java.util.List;
/**
 *
 * @author emaravi
 */
@Entity
@Table(name = "cliente")
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c")
    , @NamedQuery(name = "Cliente.findByIdcli", query = "SELECT c FROM Cliente c WHERE c.idcli = :idcli")
    , @NamedQuery(name = "Cliente.findByNombre", query = "SELECT c FROM Cliente c WHERE c.nombre = :nombre")})
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idcli")
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idcli;
    
    @Basic(optional = false)
    @Column(name = "nombre")
    @Length(min = 3, max = 50)
    private String nombre;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idcli")
    private List<Factura> facturaList;

    public Cliente() {
    }

    public Cliente(Integer idcli) {
        this.idcli = idcli;
    }

    public Cliente(Integer idcli, String nombre) {
        this.idcli = idcli;
        this.nombre = nombre;
    }

    public Integer getIdcli() {
        return idcli;
    }

    public void setIdcli(Integer idcli) {
        this.idcli = idcli;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public List<Factura> getFacturaList() {
        return facturaList;
    }

    public void setFacturaList(List<Factura> facturaList) {
        this.facturaList = facturaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcli != null ? idcli.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.idcli == null && other.idcli != null) || (this.idcli != null && !this.idcli.equals(other.idcli))) {
            return false;
        }
        return true;
    }

	@Override
	public String toString() {
		return "Cliente [idcli=" + idcli + ", nombre=" +nombre+ "]";
	}


    
}