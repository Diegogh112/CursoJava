package com.cjava.demo.pruebas;

import com.cjava.demo.domain.daos.impl.ClienteDaoImpl2;
import com.cjava.demo.domain.entities.Cliente;
import com.cjava.demo.domain.entities.Factura;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Prueba04 {
    public static void main(String[] args) {
        Cliente cliente = new Cliente(200, "Edwin Maravi");
        List<Factura> lista = new ArrayList<Factura>();
        lista.add(new Factura(57, new BigDecimal(2400) , cliente));
        lista.add(new Factura(58, new BigDecimal(2500) , cliente));
        cliente.setFacturaList(lista);

        ClienteDaoImpl2 dao = new ClienteDaoImpl2(Cliente.class);
        dao.create(cliente);

        for(Cliente c: dao.findAll()) {
            System.out.println(c);
            for(Factura f : c.getFacturaList()) {
                System.out.println(f);
            }
        }


    }
}
