package com.cjava.demo.pruebas;


import com.cjava.demo.domain.entities.Cliente;
import com.cjava.demo.domain.entities.Factura;
import jakarta.persistence.*;

import java.util.List;
import java.util.Map;

import static jakarta.persistence.Persistence.createEntityManagerFactory;
import static org.hibernate.cfg.SchemaToolingSettings.JAKARTA_HBM2DDL_DATABASE_ACTION;
import static org.hibernate.tool.schema.Action.CREATE;

public class Prueba01 {

	public static void main(String[] args) {

		var fabrica = createEntityManagerFactory("escuelaPU",
				Map.of(JAKARTA_HBM2DDL_DATABASE_ACTION, CREATE));
		//EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("escuelaPU");
		EntityManager em = fabrica.createEntityManager();
		
		//Query query = em.createQuery("SELECT c FROM Cliente c");
		Query query = em.createNamedQuery("Cliente.findAll");
		@SuppressWarnings("unchecked")
		List<Cliente> lista = (List<Cliente>)query.getResultList();
		for(Cliente c: lista) {
			System.out.println(c);
			for(Factura f: c.getFacturaList()) {
				System.out.println(f);
			}
		}

	}

}
