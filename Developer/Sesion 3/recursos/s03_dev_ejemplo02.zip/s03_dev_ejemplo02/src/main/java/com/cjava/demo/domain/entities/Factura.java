package com.cjava.demo.domain.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author emaravi
 */
@Entity
@Table(name = "factura")
@NamedQueries({
    @NamedQuery(name = "Factura.findAll", query = "SELECT f FROM Factura f")
    , @NamedQuery(name = "Factura.findByNro", query = "SELECT f FROM Factura f WHERE f.nro = :nro")
    , @NamedQuery(name = "Factura.findByImporte", query = "SELECT f FROM Factura f WHERE f.importe = :importe")})
public class Factura implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "nro")
    private Integer nro;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "importe")
    private BigDecimal importe;
    @JoinColumn(name = "idcli", referencedColumnName = "idcli")
    @ManyToOne(optional = false)
    private Cliente idcli;


    public Factura(Integer nro, BigDecimal importe, Cliente idcli) {
		super();
		this.nro = nro;
		this.importe = importe;
		this.idcli = idcli;
	}
	public Factura() {
		super();
	}

	public Factura(Integer nro) {
        this.nro = nro;
    }

    public Factura(Integer nro, BigDecimal importe) {
        this.nro = nro;
        this.importe = importe;
    }

    public Integer getNro() {
        return nro;
    }

    public void setNro(Integer nro) {
        this.nro = nro;
    }

    public BigDecimal getImporte() {
        return importe;
    }

    public void setImporte(BigDecimal importe) {
        this.importe = importe;
    }

    public Cliente getIdcli() {
        return idcli;
    }

    public void setIdcli(Cliente idcli) {
        this.idcli = idcli;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nro != null ? nro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Factura)) {
            return false;
        }
        Factura other = (Factura) object;
        if ((this.nro == null && other.nro != null) || (this.nro != null && !this.nro.equals(other.nro))) {
            return false;
        }
        return true;
    }

	@Override
	public String toString() {
		return "Factura [nro=" + nro + ", importe=" + importe + ", idcli=" + idcli + "]";
	}


    
}