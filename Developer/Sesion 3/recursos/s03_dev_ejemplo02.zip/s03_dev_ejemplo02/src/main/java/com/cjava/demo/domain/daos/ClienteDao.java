package com.cjava.demo.domain.daos;

import com.cjava.demo.domain.entities.Cliente;

import java.util.List;

public interface ClienteDao {
	public void create(Cliente cliente);
	public void update(Cliente cliente);
	public void delete(Integer id);
	public Cliente find(Integer id);
	public List<Cliente> findAll();
}
